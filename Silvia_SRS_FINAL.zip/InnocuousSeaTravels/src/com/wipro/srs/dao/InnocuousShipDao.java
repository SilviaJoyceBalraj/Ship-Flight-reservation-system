package com.wipro.srs.dao;


import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.wipro.srs.bean.CreditCardBean;
import com.wipro.srs.bean.PassengerBean;
import com.wipro.srs.bean.ReservationBean;
import com.wipro.srs.bean.RouteBean;
import com.wipro.srs.bean.ScheduleBean;
import com.wipro.srs.bean.ShipBean;

@Service("innocuousShipDao")
public class InnocuousShipDao implements InnocuousDao{

	@Autowired
	private SessionFactory sessionFactory;
	
	public String addShip(ShipBean shipBean)
	{
		Session session=sessionFactory.openSession();
		Transaction transaction=session.beginTransaction();
		String name=shipBean.getShipName().substring(0,2);
		Query query=session.createSQLQuery("select SRS_SEQ_SHIP_ID.NEXTVAL from dual");
		List l=new ArrayList();
		l=query.list();
		String edit=name+l.get(0);
		shipBean.setShipID(edit);
		session.save(shipBean);
		transaction.commit();
		session.close();
		return "SUCCESS";
	}

	public int removeShip(ShipBean shipBean) {
		sessionFactory.getCurrentSession().delete(shipBean);
		return 0;
	}

	public boolean modifyShip(ShipBean shipBean) {
		sessionFactory.getCurrentSession().update(shipBean);
		return false;
	}

	public ArrayList<ShipBean> viewByAllShips() {
		ArrayList<ShipBean> ships=new ArrayList<ShipBean>();
		Session session=sessionFactory.openSession();
		Transaction transaction=session.beginTransaction();
		Query query=session.createQuery("from ShipBean");
		ships=(ArrayList<ShipBean>) query.list();
		//session.close();
		transaction.commit();
		return ships;
	}
	public String addRoute(RouteBean routeBean)
	{
		Session session=sessionFactory.openSession();
		org.hibernate.Transaction transaction= session.beginTransaction();		
		String source=routeBean.getSource().substring(0,2);
		String destination=routeBean.getDestination().substring(0,2);
		Query query=session.createSQLQuery("select SRS_SEQ_ROUTE_ID.NEXTVAL from dual");
		List l=new ArrayList();
		l=query.list();
		String edit=source+destination+""+l.get(0);

		routeBean.setRouteID(edit);
		
		session.save(routeBean);
		transaction.commit();
		session.close();
		return "SUCCESS";
	}

	public int removeRoute(RouteBean routeBean) {
		sessionFactory.getCurrentSession().delete(routeBean);
		return 0;
	}

	public boolean modifyRoute(RouteBean routeBean) {
		sessionFactory.getCurrentSession().update(routeBean);
		return false;
	}

	@SuppressWarnings("unchecked")
	public ArrayList<RouteBean> viewByAllRoute() {
		ArrayList<RouteBean> route=new ArrayList<RouteBean>();
		Session session=sessionFactory.openSession();
		Transaction transaction=session.beginTransaction();
		Query query=session.createQuery("from RouteBean");
		route=(ArrayList<RouteBean>) query.list();
		transaction.commit();
		session.close();
		return route;
	}

	public boolean modifySchedule(ScheduleBean scheduleBean) {
		sessionFactory.getCurrentSession().update(scheduleBean);
		return false;
	}

	public ArrayList<ScheduleBean> viewByAllSchedule() {
		ArrayList<ScheduleBean> schedule=new ArrayList<ScheduleBean>();
		Session session=sessionFactory.openSession();
		Transaction transaction=session.beginTransaction();
		Query query=session.createQuery("from ScheduleBean");
		schedule=(ArrayList<ScheduleBean>) query.list();
		transaction.commit();
		session.close();
		return schedule;
	}

	public String addSchedule(ScheduleBean scheduleBean) {
		Session session=sessionFactory.openSession();
		Transaction transaction=session.beginTransaction();
		//org.hibernate.Transaction transaction= session.beginTransaction();		
		String schedule=scheduleBean.getRouteID().substring(0,4);
		Query query=session.createSQLQuery("select SRS_SEQ_SCHEDULE_ID.NEXTVAL from dual");
		List l=new ArrayList();
		l=query.list();
		String edit=schedule+""+l.get(0);

		scheduleBean.setScheduleID(edit);
		
		//System.out.println(scheduleBean.getRouteID());
		session.save(scheduleBean);
	
		transaction.commit();
		session.close();
		return "SUCCESS";
	}

	public int removeSchedule(ScheduleBean scheduleBean) {
		sessionFactory.getCurrentSession().delete(scheduleBean);
		return 0;
	}

	public ShipBean viewByShipId(String shipID) {
		ShipBean shipBean=(ShipBean)sessionFactory.getCurrentSession().get(ShipBean.class,shipID);
		return shipBean;
	}

	@Override
	public RouteBean viewByRouteId(String routeID) {
		RouteBean routeBean=(RouteBean)sessionFactory.getCurrentSession().get(RouteBean.class,routeID);
		return routeBean;
	}

	@Override
	public ScheduleBean viewByScheduleId(String scheduleID) {
		ScheduleBean scheduleBean=(ScheduleBean)sessionFactory.getCurrentSession().get(ScheduleBean.class,scheduleID);
		return scheduleBean;
	}

	
	
	
	@Override
	public ArrayList<ScheduleBean> viewScheduleByRoute(String source,String destination, Date journeyDate){
		//ScheduleBean schedule=(ScheduleBean)sessionFactory.getCurrentSession().get(ScheduleBean.class,journeyDate);
		Session session=sessionFactory.openSession();
		Transaction transaction=session.beginTransaction();
		Query dateQuery=session.createQuery("from ScheduleBean where startDate=:name");
		dateQuery.setDate("name",journeyDate);
		ArrayList<ScheduleBean> schedule=new ArrayList<ScheduleBean>();
		ArrayList<RouteBean> route=new ArrayList<RouteBean>();
		ArrayList<RouteBean> finalRoute=new ArrayList<RouteBean>();
		ArrayList<ScheduleBean> schedules=new ArrayList<ScheduleBean>();
		ArrayList<ScheduleBean> finalSchedule=new ArrayList<ScheduleBean>();
		schedule=(ArrayList<ScheduleBean>) dateQuery.list();
		for(int i=0;i<schedule.size();i++)	{
			Query query=session.createQuery("from RouteBean where source=:s AND destination=:d AND routeID=:id");
			query.setString("s",source);
			query.setString("d",destination);
			query.setString("id",schedule.get(i).getRouteID());
			route=(ArrayList<RouteBean>) query.list();
			finalRoute.addAll(route);
		}
		//if(finalRoute.size()==0)
		if(finalRoute.isEmpty())
		{
			return finalSchedule;
		}
		//	ReservationBean reservation=(ReservationBean)sessionFactory.get(ReservationBean.class,)
			Query finalQuery=session.createQuery("from ScheduleBean where routeID=:id");
			finalQuery.setString("id",finalRoute.get(0).getRouteID());
			schedules=(ArrayList<ScheduleBean>) finalQuery.list();
			finalSchedule.addAll(schedules);
			transaction.commit();
			session.close();
		return finalSchedule;
		
	}

	@Override
	public String reserve(ReservationBean reservation) {
		Session session=sessionFactory.openSession();
		Transaction transaction=session.beginTransaction();
		String name=reservation.getScheduleID().substring(0,4);
		//System.out.println(name);
		Query query=session.createSQLQuery("select SRS_SEQ_RESERVATION_ID.NEXTVAL from dual");
		List l=new ArrayList();
		l=query.list();
		String edit=name+""+l.get(0);
		//System.out.println(edit);
		reservation.setReservationID(edit);

		
		session.save(reservation);
		transaction.commit();
		session.close();
		return "SUCCESS";
	}

	@Override
	public String reserveTicket(ReservationBean reservationBean,
			ArrayList<PassengerBean> passenger) {
		
		PassengerBean passengerBean=new PassengerBean();
		passengerBean.setAge(passenger.get(0).getAge());
		passengerBean.setGender(passenger.get(0).getGender());
		passengerBean.setName(passenger.get(0).getName());
		passengerBean.setReservationID(reservationBean.getReservationID());
		passengerBean.setScheduleID(passenger.get(0).getScheduleID());
		Session session=sessionFactory.openSession();
		Transaction transaction=session.beginTransaction();
		session.save(passengerBean);
		transaction.commit();
		session.close();
		return "SUCCESS";
	}

	@Override
	public String process(CreditCardBean creditCardBean,HttpSession session) {
		String result="";
		//System.out.println(session.getAttribute("userID"));
		Session se=sessionFactory.openSession();
		Transaction tran=se.beginTransaction();
		ReservationBean reservationBean=(ReservationBean)se.get(ReservationBean.class,(String)session.getAttribute("reservationID"));
		ScheduleBean scheduleBean=(ScheduleBean)se.get(ScheduleBean.class,reservationBean.getScheduleID());
		ShipBean shipBean=(ShipBean)se.get(ShipBean.class,scheduleBean.getShipID());
		CreditCardBean creditCard=(CreditCardBean)se.get(CreditCardBean.class,creditCardBean.getCreditCardNumber());
		
		if(creditCard!=null)
		{
			if(!creditCard.getUserID().equals((String)session.getAttribute("userID")))
			{
				result="wrong";
				return result;
			}
			if(!creditCard.getValidFrom().equals(creditCardBean.getValidFrom()))
			{
				result="validfrom";
				return result;
			}
			
			
			if(!creditCard.getValidTo().equals(creditCardBean.getValidTo()))
			{
				result="validto";
				return result;
			}

			
			Double fare=reservationBean.getTotalFare();
			if(creditCard.getBalance()-fare<0)
			{
				result= "low";
			}
			else
			{	
				if(shipBean.getReservationCapacity()<reservationBean.getNoOfSeats())
				{
					Session s=sessionFactory.openSession();
					Transaction transaction=s.beginTransaction();
					creditCard.setBalance(creditCard.getBalance()-fare);
					s.update(creditCard);
					transaction.commit();
					Query qu=s.createQuery("from ReservationBean where bookingStatus!=:b and bookingStatus!=:p and scheduleID=:sid");
					qu.setString("b","Booked");
					qu.setString("p","pending");
					qu.setString("sid",scheduleBean.getScheduleID());
					List<ReservationBean> reserveList=qu.list();
					if(reserveList==null)
					{
						Transaction t=s.beginTransaction();
						reservationBean.setBookingStatus("1");
						s.update(reservationBean);
						t.commit();
					}
					else
					{
						Transaction tt=s.beginTransaction();
						reservationBean.setBookingStatus(reserveList.size()+1+"");
						s.update(reservationBean);
						tt.commit();
					}
					session.setAttribute("ticketno",reservationBean.getReservationID());
					//transaction.commit();
					result="waitingList";
					s.close();
					return result;
				}
				else{
					
					session.setAttribute("ticketno",reservationBean.getReservationID());
				shipBean.setReservationCapacity(shipBean.getReservationCapacity()-reservationBean.getNoOfSeats());
				Transaction done=se.beginTransaction();
				creditCard.setBalance(creditCard.getBalance()-fare);
				done.commit();
				Transaction done1=se.beginTransaction();
				reservationBean.setBookingStatus("Booked");
				done1.commit(); 
				result="SUCCESS";
				
				return result;
				}
			}
		}
		else
		{
			result="creditCardNumber";
		}
		tran.commit();
		se.close();
		result="FAIL";
		return result;
	}

	@Override
	public boolean cancelTicket(String reservationID) {
		Session session=sessionFactory.openSession();		
		ReservationBean reservationBean=(ReservationBean)session.get(ReservationBean.class,reservationID);
		if(reservationBean==null){
			return false;}
		if(reservationBean.getJourneyDate().compareTo(new Date())<=0)
		{
			return false;
		}
		
		Transaction transaction=session.beginTransaction();
		Query query=session.createQuery("from PassengerBean where reservationID=:id");
		query.setString("id",reservationID);
		ArrayList passengers=(ArrayList) query.list();
		for(int i=0;i<passengers.size();i++)
		{
		session.delete(passengers.get(i));
		}
		transaction.commit();
		Transaction t=session.beginTransaction();
		ScheduleBean scheduleBean=(ScheduleBean)session.get(ScheduleBean.class,reservationBean.getScheduleID());

		ShipBean shipBean=(ShipBean)session.get(ShipBean.class,scheduleBean.getShipID());
		shipBean.setReservationCapacity(shipBean.getReservationCapacity()+reservationBean.getNoOfSeats());
		//update credit balance
		//CreditCardBean creditCardBean=(CreditCardBean)sessionFactory.getCurrentSession().get(CreditCardBean.class,reservationBean.getUserID());
		Query credit=session.createQuery("from CreditCardBean where userID=:rid");
		credit.setString("rid",reservationBean.getUserID());
		List creditCard=credit.list();
		CreditCardBean creditCardBeans=(CreditCardBean) creditCard.get(0);
		creditCardBeans.setBalance(creditCardBeans.getBalance()+reservationBean.getTotalFare());
		session.update(creditCardBeans);
		t.commit();
		
		Transaction don=session.beginTransaction();
		Query qu=session.createQuery("from ReservationBean where reservationID=:rrid and bookingStatus!=:bo and bookingStatus!=:pe");
		qu.setString("rrid",reservationID);
		qu.setString("bo","Booked");
		qu.setString("pe","pending");
		List<ReservationBean> wl=qu.list();
		
		//if(wl.size()>0)
		if(!wl.isEmpty())
		{	
			shipBean.setReservationCapacity(shipBean.getReservationCapacity()-reservationBean.getNoOfSeats());
			int count=Integer.parseInt(wl.get(0).getBookingStatus());
			Query li=session.createQuery("from ReservationBean where bookingStatus!=:bk and bookingStatus!=:pd and scheduleID=:sssid");
			li.setString("bk","Booked");
			li.setString("pd","pending");
			li.setString("sssid",scheduleBean.getScheduleID());
			List<ReservationBean> lis=li.list();

			for(int ind=0;ind<lis.size();ind++)
			{			
				
				if(Integer.parseInt(lis.get(ind).getBookingStatus())>count)
					{
						lis.get(ind).setBookingStatus((Integer.parseInt(lis.get(ind).getBookingStatus())-1+""));
					}
				session.update(lis.get(ind));
				
			}
			don.commit();
			
		}
	
		
		ReservationBean re=(ReservationBean)session.get(ReservationBean.class, reservationBean.getReservationID());
	

		Session se=sessionFactory.openSession();
		Transaction tra=se.beginTransaction();
		se.delete(re);
		tra.commit();
		se.close();
		
		while(true){
		Query waits=session.createQuery("from ReservationBean where bookingStatus=:status and scheduleID=:ssid");
		waits.setString("status","1");
		waits.setString("ssid",scheduleBean.getScheduleID());
		List<ReservationBean> waitList=waits.list();
	//	Transaction waitingTransaction=session.beginTransaction();

		//if(waitList.size()==0)
		if(waitList.isEmpty()){
			break;}
		else{
			if(shipBean.getReservationCapacity()<waitList.get(0).getNoOfSeats()){
				break;}
		}
		if(shipBean.getReservationCapacity()>=waitList.get(0).getNoOfSeats())
		{
			Transaction trans=session.beginTransaction();
			waitList.get(0).setBookingStatus("Booked");
			session.update(waitList.get(0));
			trans.commit();
			Transaction tt=session.beginTransaction();
			shipBean.setReservationCapacity(shipBean.getReservationCapacity()-waitList.get(0).getNoOfSeats());
			session.update(shipBean);
			tt.commit();
			Query all=session.createQuery("from ReservationBean where bookingStatus!=:b and bookingStatus!=:p and scheduleID=:sid");
			all.setString("b","Booked");
			all.setString("p","pending");
			all.setString("sid",scheduleBean.getScheduleID());
			List<ReservationBean> waiting=all.list();
			
			for(int waitingIndex=0;waitingIndex<waiting.size();waitingIndex++)
			{
				int waitingId=Integer.parseInt(waiting.get(waitingIndex).getBookingStatus());
				Session s=sessionFactory.openSession();
				Transaction tr=s.beginTransaction();
				waiting.get(waitingIndex).setBookingStatus(Integer.parseInt(waiting.get(waitingIndex).getBookingStatus())-1+"");
				s.update(waiting.get(waitingIndex));
				tr.commit();
				s.close();
			}
			
			//waitingTransaction.commit();
		}
		
		}
		session.close();
		return true;
	}

	@Override
	public ArrayList<PassengerBean> viewPassengersByShip(String scheduleID) {
		Session session=sessionFactory.openSession();
		Transaction transaction=session.beginTransaction();
		Query query=session.createQuery("from PassengerBean where scheduleID=:sid");
		query.setString("sid",scheduleID);
		ArrayList<PassengerBean> passengerBean=(ArrayList<PassengerBean>) query.list();
		transaction.commit();
		session.close();
		return passengerBean;
	}

	@Override
	public int capacity(String sid) {
		
		ScheduleBean scheduleBean=(ScheduleBean)sessionFactory.getCurrentSession().get(ScheduleBean.class,sid);
		ShipBean shipBean=(ShipBean)sessionFactory.getCurrentSession().get(ShipBean.class,scheduleBean.getShipID());
		int seatsLeft=shipBean.getReservationCapacity();
		return seatsLeft;
	}

	@Override
	public Map<ReservationBean, ArrayList<PassengerBean>> viewTicket(
			String reservationID) {
		Map<ReservationBean,ArrayList<PassengerBean>> map=new HashMap<ReservationBean,ArrayList<PassengerBean>>();
		Session session=sessionFactory.openSession();
		Transaction transaction=session.beginTransaction();
		ReservationBean reservation=(ReservationBean)session.get(ReservationBean.class,reservationID);
		if(reservation==null){
			return map;}
		Query query=session.createQuery("from PassengerBean where reservationID=:rid");
		query.setString("rid",reservationID);
		ArrayList<PassengerBean> list=(ArrayList<PassengerBean>) query.list();
		ReservationBean reservationBean=(ReservationBean)session.get(ReservationBean.class,reservationID);
		map.put(reservationBean,list);
		transaction.commit();
		session.close();
		return map;
		
	}

	@Override
	public ScheduleBean journey(String scheduleID) {
		ScheduleBean scheduleBean=(ScheduleBean)sessionFactory.getCurrentSession().get(ScheduleBean.class,scheduleID);
		return scheduleBean;
	}

	@Override
	public boolean verify(String reservationID, HttpSession session) {
		//Session sessions=sessionFactory.getCurrentSession();
		ReservationBean reservationBean=(ReservationBean)sessionFactory.getCurrentSession().get(ReservationBean.class,reservationID);
		if(reservationBean!=null)
		{
			if(reservationBean.getUserID().equals((String)session.getAttribute("userID"))){
				return true;}
			
		}
		return false;
	}

	public boolean updateBalanceShip(String shipID) {
		
		
		Session session=sessionFactory.openSession();
		Transaction transaction=session.beginTransaction();
		Query query=session.createQuery("from ScheduleBean where shipID=:sid");
		query.setString("sid",shipID);
		List<ScheduleBean> lis=query.list();
		for(int index=0;index<lis.size();index++)
		{
			Query rquery=session.createQuery("from ReservationBean where scheduleID=:sid");
			rquery.setString("sid",lis.get(index).getScheduleID());
			List<ReservationBean> rlist=rquery.list();
			for(int rindex=0;rindex<rlist.size();rindex++)
			{
				Query cquery=session.createQuery("from CreditCardBean where userID=:uid");
				cquery.setString("uid",rlist.get(rindex).getUserID());
				List<CreditCardBean> clist=cquery.list();
				for(int cindex=0;cindex<clist.size();cindex++)
				{
					clist.get(cindex).setBalance(clist.get(cindex).getBalance()+rlist.get(rindex).getTotalFare());
					session.update(clist.get(cindex));
				}
				/*CreditCardBean creditCardBean=(CreditCardBean)sessionFactory.getCurrentSession().get(CreditCardBean.class,rlist.get(rindex).getUserID());
				creditCardBean.setBalance(creditCardBean.getBalance()+rlist.get(rindex).getTotalFare());*/
			}
		}
		//session.close();
		transaction.commit();
		return true;
	}

	public boolean updateBalanceRoute(String routeID) {
		
		Session session=sessionFactory.openSession();
		Transaction transaction=session.beginTransaction();
		Query query=session.createQuery("from ScheduleBean where routeID=:rid");
		query.setString("rid",routeID);
		List<ScheduleBean> lis=query.list();
		for(int sindex=0;sindex<lis.size();sindex++)
		{
			Query squery=session.createQuery("from ShipBean where shipID=:shipid");
			squery.setString("shipid",lis.get(sindex).getShipID());
			List<ShipBean> shipList=squery.list();
			for(int shipIndex=0;shipIndex<shipList.size();shipIndex++)
			{
				shipList.get(shipIndex).setReservationCapacity(shipList.get(shipIndex).getSeatingCapacity());
				session.update(shipList.get(shipIndex));
			}
		}
		for(int index=0;index<lis.size();index++)
		{
		//	boolean status=updateBalanceSchedule(lis.get(index).getScheduleID());
			Query rquery=session.createQuery("from ReservationBean where scheduleID=:sid");
			rquery.setString("sid",lis.get(index).getScheduleID());
			List<ReservationBean> rlist=rquery.list();
			for(int rindex=0;rindex<rlist.size();rindex++)
			{
				Query cquery=session.createQuery("from CreditCardBean where userID=:uid");
				cquery.setString("uid",rlist.get(rindex).getUserID());
				List<CreditCardBean> clist=cquery.list();
				for(int cindex=0;cindex<clist.size();cindex++)
				{
					clist.get(cindex).setBalance(clist.get(cindex).getBalance()+rlist.get(rindex).getTotalFare());
					session.update(clist.get(cindex));
				}
			}
		}
		transaction.commit();
		session.close();
		//Query roquery=session.createQuery("from Bean where routeID=:rid");
		
		return true;
	}

	public boolean updateBalanceSchedule(String scheduleID) {
		Session session=sessionFactory.openSession();
		Transaction transaction=session.beginTransaction();
		
		
		ScheduleBean schedule=(ScheduleBean)session.get(ScheduleBean.class,scheduleID);
		
		ShipBean ship=(ShipBean)session.get(ShipBean.class,schedule.getShipID());
			
				ship.setReservationCapacity(ship.getSeatingCapacity());
				session.update(ship);
		
		
		
		Query rquery=session.createQuery("from ReservationBean where scheduleID=:sid");
		rquery.setString("sid",scheduleID);
		List<ReservationBean> rlist=rquery.list();
		for(int rindex=0;rindex<rlist.size();rindex++)
		{
			Query cquery=session.createQuery("from CreditCardBean where userID=:uid");
			cquery.setString("uid",rlist.get(rindex).getUserID());
			List<CreditCardBean> clist=cquery.list();
			for(int cindex=0;cindex<clist.size();cindex++)
			{
				clist.get(cindex).setBalance(clist.get(cindex).getBalance()+rlist.get(rindex).getTotalFare());
				session.update(clist.get(cindex));
			}
		}
		transaction.commit();
		session.close();
		return true;
	}

	public List<PassengerBean> getTicket(String reservationID) {
		
		Session session=sessionFactory.openSession();
		Transaction transaction=session.beginTransaction();
		Query query=session.createQuery("from PassengerBean where reservationID=:rid");
		query.setString("rid",reservationID);
		List<PassengerBean> passengerList=query.list();
		transaction.commit();
		session.close();
		return passengerList;
	}

}
