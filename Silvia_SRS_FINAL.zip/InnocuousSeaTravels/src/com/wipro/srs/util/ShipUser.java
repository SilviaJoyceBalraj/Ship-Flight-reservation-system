package com.wipro.srs.util;



import java.util.ArrayList;
import java.util.List;


import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.classic.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wipro.srs.bean.CredentialsBean;

import com.wipro.srs.bean.PassengerBean;
import com.wipro.srs.bean.ProfileBean;
import com.wipro.srs.bean.ReservationBean;

@Service("user")
@Transactional
public class ShipUser implements User2{
	@Autowired
	private Authentication authentication;
	@Autowired
	private SessionFactory sessionFactory;
	public String login(CredentialsBean credentialsBean)
	{
		String result="AB";
		boolean test=authentication.authenticate(credentialsBean);
		if(test)
		{
			String authorize=authentication.authorize(credentialsBean.getUserID());
			if("A".equals(authorize))
			{
				result="A";
			}
			if("C".equals(authorize))
			{
				result="C";
			}
			if("AB".equals(authorize))
			{
				result="FAIL";
			}

		}
		else
		{
			result="INVALID";
		}
		return result;
	}
	
	public boolean logout(String userID)
	{
		CredentialsBean credentialsBean=(CredentialsBean) sessionFactory.getCurrentSession().get(CredentialsBean.class,userID);
		credentialsBean.setLoginStatus(0);
		Session session=sessionFactory.openSession();
		Query query=session.createQuery("from ReservationBean where userID=:id and bookingStatus=:status");
		query.setString("id",userID);
		
		query.setString("status","pending");
		ArrayList<ReservationBean> reserve=(ArrayList<ReservationBean>) query.list();
		for(int index=0;index<reserve.size();index++)
		{
			Query passenger=session.createQuery("from PassengerBean where reservationID=:rid");
			passenger.setString("rid",reserve.get(index).getReservationID());
			ArrayList<PassengerBean> pending=(ArrayList<PassengerBean>) passenger.list();
			for(int delIndex=0;delIndex<pending.size();delIndex++)
			{
				Transaction transaction=session.beginTransaction();

				session.delete(pending.get(delIndex));
				transaction.commit();
			}	
			/*
			Transaction shipTransaction=session.beginTransaction();
			ScheduleBean scheduleBean=(ScheduleBean)sessionFactory.getCurrentSession().get(ScheduleBean.class,reserve.get(index).getScheduleID());
			ShipBean shipBean=(ShipBean)sessionFactory.getCurrentSession().get(ShipBean.class,scheduleBean.getShipID());
			shipBean.setReservationCapacity(shipBean.getReservationCapacity()+reserve.get(index).getNoOfSeats());
			System.out.println("Updating cancelled Ship seats");
			shipTransaction.commit();*/
		}
		
		for(int delIndex1=0;delIndex1<reserve.size();delIndex1++)
		{
			Transaction reserveTransaction=session.beginTransaction();

			session.delete(reserve.get(delIndex1));
			reserveTransaction.commit();
		}
		session.close();
		return true;
	}
	public String changePassword(CredentialsBean credentialsBean,String newPassword)
	{
		String result="";
		CredentialsBean credentials=(CredentialsBean)sessionFactory.getCurrentSession().get(CredentialsBean.class,credentialsBean.getUserID());
		if(credentials.getPassword().equals(credentialsBean.getPassword()))
		{
			Session session=sessionFactory.openSession();
			Transaction transaction=session.beginTransaction();
			credentials.setPassword(newPassword);
			session.update(credentials);
			transaction.commit();
			session.close();
			result="SUCCESS";
			return result;
		}
		else
		{
			result="INVALID";
			return result;
		}
	}
	public String register(ProfileBean profileBean)
	{
		Session session=sessionFactory.openSession();
		Transaction transaction=session.beginTransaction();
		String firstName=profileBean.getFirstName().substring(0,2);
		CredentialsBean credentials=new CredentialsBean();
		Query query=session.createSQLQuery("select SRS_SEQ_USER_ID.NEXTVAL from dual");
		List list=new ArrayList();
		list=query.list();
		String str=list+"";
		firstName=firstName+""+str.substring(1,5);
		profileBean.setUserID(firstName);
		credentials.setUserID(firstName);
		credentials.setLoginStatus(0);
		credentials.setPassword(profileBean.getPassword());
		credentials.setUserType("C");
		sessionFactory.getCurrentSession().save(credentials);
		transaction.commit();
		sessionFactory.getCurrentSession().save(profileBean);
		
		CredentialsBean credentialsBean=(CredentialsBean)sessionFactory.getCurrentSession().get(CredentialsBean.class,firstName);
		if(credentialsBean!=null)
		{
			return firstName;
		}
		session.close();
		return "FAIL";
	}
}
