package com.wipro.srs.util;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wipro.srs.bean.CredentialsBean;


@Service("authentication")
@Transactional
public class UserAuthentication implements Authentication{
	
	@Autowired
	private SessionFactory sessionFactory;
	public boolean authenticate(CredentialsBean credentialsBean)
	{
		CredentialsBean credentials=(CredentialsBean)sessionFactory.getCurrentSession().get(CredentialsBean.class,credentialsBean.getUserID());
		if(credentials==null)
			return false;
		if(credentials.getPassword().equals(credentialsBean.getPassword()))
			{
				return true;
			}
		else
		{
			return false;
		}
			
	}
	public String authorize(String userID)
	{
		CredentialsBean credentials=(CredentialsBean)sessionFactory.getCurrentSession().get(CredentialsBean.class,userID);
		return credentials.getUserType();
	}
	public boolean changeLoginStatus(CredentialsBean credentialsBean,int loginStatus)
	{
		CredentialsBean credentials=(CredentialsBean)sessionFactory.getCurrentSession().get(CredentialsBean.class,credentialsBean.getUserID());
		if(credentials.getLoginStatus()==loginStatus)
		{

			return false;
		}

		credentials.setLoginStatus(loginStatus);
		return true;
	}

}
