package com.wipro.srs.util;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


@Service("payment")
@Transactional
public class BillPayment implements Payment{
	public boolean findByCardNumber(String userID,String cardNumber)
	{
		return true;
	}
	public String process(Payment payment)
	{
		return "d";
	}
}
