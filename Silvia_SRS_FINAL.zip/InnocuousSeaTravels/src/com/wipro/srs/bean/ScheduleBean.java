package com.wipro.srs.bean;

import java.util.Date;

import javax.persistence.Entity;


import javax.persistence.Id;

import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.Future;
import javax.validation.constraints.NotNull;


import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.format.annotation.DateTimeFormat;
//@SequenceGenerator(name="seq",sequenceName="SRS_SEQ_SCHEDULE_ID")
@Entity
@Table(name="SRS_TBL_Schedule")
public class ScheduleBean {

@Id
@NotEmpty
//@GeneratedValue(strategy=GenerationType.AUTO,generator="seq")
private String scheduleID;
@NotEmpty(message="shipId must not be empty")
private String shipID;
@NotEmpty(message="routeId must not be empty")
private String routeID;
@NotNull
@Future
@DateTimeFormat(pattern="MM/dd/yyyy")
private Date startDate;
@Transient
private String start;
public String getStart() {
	return start;
}
public void setStart(String start) {
	this.start = start;
}
public String getScheduleID() {
	return scheduleID;
}
public void setScheduleID(String scheduleID) {
	this.scheduleID = scheduleID;
}
public String getShipID() {
	return shipID;
}
public void setShipID(String shipID) {
	this.shipID = shipID;
}
public String getRouteID() {
	return routeID;
}
public void setRouteID(String routeID) {
	this.routeID = routeID;
}
public Date getStartDate() {
	return startDate;
}
public void setStartDate(Date startDate) {
	this.startDate = startDate;
}

	
}
