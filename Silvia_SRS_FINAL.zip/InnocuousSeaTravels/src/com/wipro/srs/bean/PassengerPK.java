package com.wipro.srs.bean;

import java.io.Serializable;


public class PassengerPK implements Serializable{

		private String reservationID;
		private String name;
		public String getReservationID() {
			return reservationID;
		}
		public void setReservationID(String reservationID) {
			this.reservationID = reservationID;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
}
