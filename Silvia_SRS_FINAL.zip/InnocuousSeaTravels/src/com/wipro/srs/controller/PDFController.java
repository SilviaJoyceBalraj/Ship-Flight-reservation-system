package com.wipro.srs.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.wipro.srs.bean.PassengerBean;
import com.wipro.srs.service.Administrator;
@Controller

public class PDFController {
@Autowired
private Administrator shipAdministrator;
	 @RequestMapping(value = "/downloadPDF", method = RequestMethod.GET)
	    public ModelAndView downloadExcel(HttpSession session) {
	       
		  String reservationID=session.getAttribute("ticketid")+"";
		  List<PassengerBean> passengers=shipAdministrator.getTicket(reservationID);
		  ModelAndView mav = new ModelAndView()  ;
	        mav.addObject("listPassengers", passengers) ;
	        mav.setView(new PDFBuilder()) ;
	        return mav ;
	    }
}
