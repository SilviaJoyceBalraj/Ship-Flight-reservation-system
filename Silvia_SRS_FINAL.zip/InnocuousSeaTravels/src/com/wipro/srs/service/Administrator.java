package com.wipro.srs.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import com.wipro.srs.bean.CreditCardBean;
import com.wipro.srs.bean.PassengerBean;
import com.wipro.srs.bean.ReservationBean;
import com.wipro.srs.bean.RouteBean;
import com.wipro.srs.bean.ScheduleBean;
import com.wipro.srs.bean.ShipBean;


public interface Administrator {
	
	

	 String addShip(ShipBean shipBean);

	 int removeShip(ShipBean shipBean);

	

	 boolean modifyShip(ShipBean shipBean);

	 List<ShipBean> viewByAllShips();
	 List<RouteBean> viewByAllRoute();

	 String addRoute(RouteBean routeBean);

	 int removeRoute(RouteBean routeBean);

	 boolean modifyRoute(RouteBean routeBean);

	 boolean modifySchedule(ScheduleBean scheduleBean);

	 List<ScheduleBean> viewByAllSchedule();

	 String addSchedule(ScheduleBean scheduleBean);
	 int removeSchedule(ScheduleBean scheduleBean);


	 ShipBean viewByShipId(String shipID);

	 RouteBean viewByRouteId(String routeID);

	 ScheduleBean viewByScheduleId(String scheduleID);
	 ArrayList<ScheduleBean> viewScheduleByRoute(String source,String destination,Date journeyDate);

	 String reserve(ReservationBean reservation);

	

	 String reserveTicket(ReservationBean reservationBean,
			ArrayList<PassengerBean> passenger);

	 String process(CreditCardBean creditCardBean,HttpSession session);

	 boolean cancelTicket(String reservationID);

	

	 ArrayList<PassengerBean> viewPassengersByShip(String scheduleID);

	 int capacity(String sid);

	 Map<ReservationBean, ArrayList<PassengerBean>> viewTicket(
			String reservationID);

	 ScheduleBean journey(String scheduleID);


	 boolean verify(String reservationID, HttpSession session);
	 boolean updateBalanceShip(String shipID);
	 boolean updateBalanceRoute(String routeID);
	 boolean updateBalanceSchedule(String scheduleID);


	
	List<PassengerBean> getTicket(String reservationID);
	

}
